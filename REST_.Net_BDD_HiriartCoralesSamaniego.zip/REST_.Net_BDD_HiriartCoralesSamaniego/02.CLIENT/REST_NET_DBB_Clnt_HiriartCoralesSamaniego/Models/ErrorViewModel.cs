namespace REST_dotNET_DBB_Clnt_HiriartCoralesSamaniego.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}