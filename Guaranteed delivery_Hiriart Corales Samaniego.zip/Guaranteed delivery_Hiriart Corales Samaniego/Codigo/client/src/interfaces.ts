export interface Message {
  body: number;
}
